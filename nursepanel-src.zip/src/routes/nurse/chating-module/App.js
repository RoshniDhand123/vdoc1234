import React, { useState, useCallback, useMemo, useRef } from "react";
import useWebSocket, { ReadyState } from "react-use-websocket";
import "./index.css";
const socketUrl = "ws://192.168.4.54:8001/uui";
const WebSocketDemo = () => {
  //Public API that will echo messages sent to it back to the client
  const messageHistory = useRef([]);
  const { sendMessage, lastMessage, readyState, getWebSocket } = useWebSocket(
    socketUrl
  );

  messageHistory.current = useMemo(
    () => messageHistory.current.concat(lastMessage),
    [lastMessage]
  );

  const handleClickSendMessage = useCallback(() => sendMessage("Hello"), []);

  const connectionStatus = {
    [ReadyState.CONNECTING]: "Connecting...",
    [ReadyState.OPEN]: "Connected",
    [ReadyState.CLOSING]: "Disconnecting...",
    [ReadyState.CLOSED]: "Disconnected",
    [ReadyState.UNINSTANTIATED]: "Uninstantiated",
  }[readyState];

  const handleSendMsg = (e) => {
    const formData = new FormData(e.currentTarget);
    e.preventDefault();
    const msg = formData.get("msg");
    console.log(msg);
    if (msg) sendMessage(msg);
  };
  return (
    <div className="chat-box">
      <span className="title">
        The WebSocket is currently{" "}
        <b className={connectionStatus.replace("...", "").toLocaleLowerCase()}>
          {connectionStatus}
        </b>
      </span>
      <h3>
        {lastMessage ? <span>Last message: {lastMessage.data}</span> : null}
      </h3>
      <ul>
        {messageHistory.current.map((message, idx) =>
          message ? <li key={idx}>{message.data}</li> : null
        )}
      </ul>
      <div className="title">
        <form onSubmit={handleSendMsg}>
          <input name="msg" required />
          <button type="submit">Send</button>
        </form>
      </div>
    </div>
  );
};
export default WebSocketDemo;
