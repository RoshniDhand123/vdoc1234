import React, { useState } from "react";
import ButtonComponent from "../../../components/button";
import { userChat } from "../../../services/apis";
import "./style.css";


const Detail = (props) => {
	const [data, setReportData] = React.useState();
	const [previous, setPrevious] = React.useState(true);
	const [physicianId, setPhysicianId ]= useState(props.prevReport[0].Id);

	console.log('hshhs',props)
	
    const handleChatClick = async () => {
		setPhysicianId(props.prevReport[0].Id);
		let resp = await userChat(physicianId)
	};
	const getReportData = (e) => {
		//console.log("e", e.target.value);
		setReportData(e.target.value);
	};
	const handlePreviousFile = () => {
		setPrevious(!previous);
	};
	const show = (list) => {
		return (
			<div style={{ borderBottom: "1px solid white",  }}>
				{Object.entries(list).map(([key, value], index) => {
					return (<div className='datatab' style={{display:"flex"}}>
						
							<div className="heading">{key}:</div>
							<div className="info">{value}</div>
							{/* {{key} === "Image"?<div> <div className="heading">{key}:</div>
							<img className="pic" alt="pic" src={`http://192.168.4.54:8001${value}`}/> </div> : <div style={{display:"flex"}}><div className="heading">{key}:</div>
							<div className="info">{value}</div></div>  }  */}
				
						</div>
					); 
				})}
			</div>
		);
	};

	console.log("prevReport", props.prevReport);	
	return (
		
		<div className="PatientDetailContainer">
			{previous ? (
				<div className="previous-record">
					{props.prevReport.length > 0 ? (
						props.prevReport.map(show)
					) : (
						<div>Previous Report not exist</div>
					)}
					{/* {Object.entries(previousReport).map(([key, value]) => {
						return (
							<div>
								<div className="heading">{key}</div>
								<div>{value}</div>
							</div>
						);
					})} */}
				</div>
			) : (
				<textarea
					className="textArea"
					value={data}
					onChange={getReportData}
				></textarea>
			)}
			<div className="buttonContainer">
				<ButtonComponent
					btnText={previous ? "Chat" : "Detail"}
					className="nurse btn buttonStyle"
					onClick={handleChatClick}
				/>
				{!previous ?<ButtonComponent
					btnText="Submit"
					className="nurse btn buttonStyle"
					onClick={() => props.buttonAction(data)}
				/>:""}
				<ButtonComponent
					btnText="Cancel"
					className="nurse btn buttonStyle"
					onClick={() => props.buttonAction("cancelButton")}
				/>
			</div>
		</div>
	);
};
export default Detail;
