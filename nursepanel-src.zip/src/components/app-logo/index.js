
const AppLogo = ({ logo,className }) => {
  return (
    <div>
        <img src={logo} alt="Logo"  className={className}/>
    </div>
  );
};

export default AppLogo;
